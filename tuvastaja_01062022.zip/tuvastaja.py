#!/usr/bin/python3
#
# Copyright (c) 2020, NVIDIA CORPORATION. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
#

from signal import pause
import jetson.inference
import jetson.utils

import argparse
import sys
import time
import relay_control
from j2tk import J2tk


# tunable parameters
cutterDistance = 200 # 1lõikaja vahemaa kaamerast
extraLength = 18 # + liidetav nimetis, et teha õige lõike otsus
speedFactor = 4.95 # lindi enda kiirus, tuletis
cutterDelay = 5.0 # viide lindi seisust lõikmise lõpuni
strawNotDetectedPeriod = 2.0   # in seconds
decelerationTime = 0.15 # konveieri lindi enda aeglustuse nihe
minDistanceBetweenJ2tkInPixels = 150 # 2ra muuda
maxDiffBetweenLastDistance = 20 # 2ra muuda

# parse the command line
parser = argparse.ArgumentParser(description="Locate objects in a live camera stream using an object detection DNN.", 
                                 formatter_class=argparse.RawTextHelpFormatter, epilog=jetson.inference.detectNet.Usage() +
                                 jetson.utils.videoSource.Usage() + jetson.utils.videoOutput.Usage() + jetson.utils.logUsage())

parser.add_argument("input_URI", type=str, default="", nargs='?', help="URI of the input stream")
parser.add_argument("output_URI", type=str, default="", nargs='?', help="URI of the output stream")
parser.add_argument("--network", type=str, default="ssd-mobilenet-v2", help="pre-trained model to load (see below for options)")
parser.add_argument("--overlay", type=str, default="box,labels,conf", help="detection overlay flags (e.g. --overlay=box,labels,conf)\nvalid combinations are:  'box', 'labels', 'conf', 'none'")
parser.add_argument("--threshold", type=float, default=0.5, help="minimum detection threshold to use") 

is_headless = ["--headless"] if sys.argv[0].find('console.py') != -1 else [""]

try:
	opt = parser.parse_known_args()[0]
except:
	print("")
	parser.print_help()
	sys.exit(0)

relay_control.relay_setup()
time.sleep(0.25)
relay_control.resume_movement()

# create video output object
output = jetson.utils.videoOutput(opt.output_URI, argv=sys.argv+is_headless)

# load the object detection network
net = jetson.inference.detectNet(opt.network, sys.argv, opt.threshold)

# create video sources & outputs
input = jetson.utils.videoSource(opt.input_URI, argv=sys.argv)

# image variables
imgBlank = jetson.utils.loadImage('/home/tanel372/tuvastaja/blank.png')
imgPointer = jetson.utils.loadImage('/home/tanel372/tuvastaja/pointer.png')
imgPointer2 = jetson.utils.loadImage('/home/tanel372/tuvastaja/pointer2.png')
imgNumbers = []
for i in range(10):
	imgNumbers.append(jetson.utils.loadImage('/home/tanel372/tuvastaja/nr' + str(i) + '.png'))
img = input.Capture()
imgOut = jetson.utils.cudaAllocMapped(width=1920, height=480, format=img.format)

# internal variables
strawLengthInPixels150 = 150 * 1.882   # straw length in pixels can be calculated by multiplying length in mm by 1.882
strawLengthInPixels200 = 200 * 1.882
xPositions = []
xPositions.append(J2tk(0.0, False))
beforeLastDetectedOts = J2tk(0.0, False)
lastDetectedOts = J2tk(0.0, False)
beforeLastDetectedJ2tk = J2tk(0.0, False)
lastDetectedJ2tk = J2tk(0.0, False)
movementPaused = False
decelerating = False
pauseTime = time.time()
cutterDistInScreen = 1280.0 - cutterDistance * 1.882
isFrameWithoutDetection = False
withoutStrawStartTime = time.time()
isTuvastajaEmpty = False

def checkDetectedArea(x, y, category):
	global xPositions
	if category == 'ots' and not checkIfOtsExists(x):
		# check if detected ots is reappearing and not just some random false detection
		global lastDetectedOts
		global beforeLastDetectedOts
		if x < lastDetectedOts.xPos + maxDiffBetweenLastDistance and x > lastDetectedOts.xPos - maxDiffBetweenLastDistance:
			if lastDetectedOts.xPos < beforeLastDetectedOts.xPos + maxDiffBetweenLastDistance and lastDetectedOts.xPos > beforeLastDetectedOts.xPos - maxDiffBetweenLastDistance:
				print(">>>>>>>>>>>>>>>>>>>> ots detected")
				xPositions[0] = J2tk(x, False)
				#xPositions.clear
				#xPositions = []
				#xPositions.append(J2tk(x, False))
		beforeLastDetectedOts = J2tk(lastDetectedOts.xPos, False)
		lastDetectedOts = J2tk(x, False)

	elif category == 'j2tk' and not checkIfJ2tkExists(x):
		# check if detected j2tk is reappearing and not just some random false detection
		global lastDetectedJ2tk
		global beforeLastDetectedJ2tk
		if x < lastDetectedJ2tk.xPos + maxDiffBetweenLastDistance and x > lastDetectedJ2tk.xPos - maxDiffBetweenLastDistance:
			if lastDetectedJ2tk.xPos < beforeLastDetectedJ2tk.xPos + maxDiffBetweenLastDistance and lastDetectedJ2tk.xPos > beforeLastDetectedJ2tk.xPos - maxDiffBetweenLastDistance:
				#print(">>>>>>>>>>>>>>>>>>>> j2tk added")
				if len(xPositions) < 10:
					# if j2tk position distance is more than straw length away from ots and previous j2tk then mark that j2tk for cutting
					if (len(xPositions) > 1) and (x - xPositions[len(xPositions) - 1].xPos > strawLengthInPixels200 + extraLength) and (x - xPositions[1].xPos > strawLengthInPixels200 + extraLength):
						xPositions.append(J2tk(x, True, 200))
					elif (len(xPositions) > 1) and (x - xPositions[len(xPositions) - 1].xPos > strawLengthInPixels150 + extraLength) and (x - xPositions[1].xPos > strawLengthInPixels150 + extraLength):
						xPositions.append(J2tk(x, True, 150))
					elif (len(xPositions) == 1):
						xPositions.append(J2tk(x, False))
		beforeLastDetectedJ2tk = J2tk(lastDetectedJ2tk.xPos, False)
		lastDetectedJ2tk = J2tk(x, False)

def checkIfOtsExists(x):
	exists = False
	_j2tk = xPositions[0]
	if x > 0 and x < _j2tk.xPos + minDistanceBetweenJ2tkInPixels and x > _j2tk.xPos - minDistanceBetweenJ2tkInPixels:
		exists = True

	return exists

def checkIfJ2tkExists(x):
	exists = False
	for _j2tk in xPositions:
		if x > 0 and x < _j2tk.xPos + minDistanceBetweenJ2tkInPixels and x > _j2tk.xPos - minDistanceBetweenJ2tkInPixels:
			exists = True
			break

	return exists


def updateMovement():
	global xPositions
	global cutterDistInScreen
	global pauseTime
	global movementPaused
	global decelerating

	if time.time() > pauseTime + cutterDelay and movementPaused:
		movementPaused = False
		relay_control.resume_movement()
	if time.time() > pauseTime + decelerationTime and movementPaused:
		decelerating = False
		#relay_control.stop_cut_impulse()

	jetson.utils.cudaDrawLine(imgOut, (cutterDistInScreen, 120), (cutterDistInScreen, 360), (192, 0, 0, 255), 3)

	if xPositions[0].xPos >= cutterDistInScreen:
		if not movementPaused or decelerating:
			xPositions[0].xPos -= speedFactor
		jetson.utils.cudaOverlay(imgPointer2, imgOut, xPositions[0].xPos, 240)

	for i in range(0, len(xPositions)):
		if i > 0:
			if xPositions[i].xPos >= cutterDistInScreen:
				if not movementPaused or decelerating:
					xPositions[i].xPos -= speedFactor
				_xPos = xPositions[i].xPos
				jetson.utils.cudaOverlay(imgNumbers[i], imgOut, _xPos, 240)
				if xPositions[i].cut:
					jetson.utils.cudaDrawLine(imgOut, (_xPos + 12, 230), (_xPos + 12, 266), (0, 0, 192, 192), 2)
			else:
				if xPositions[i].cut and not movementPaused:
					print(">>>> cutting.. " + str(xPositions[i].cutLength))
					if (xPositions[i].cutLength == 200):
						relay_control.cut_length_200
					else:
						relay_control.cut_length_150
					movementPaused = True
					decelerating = True
					pauseTime = time.time()
					relay_control.pause_movement()
					#relay_control.start_cut_impulse()
					xPositions.remove(xPositions[i])
					break


# process frames until the user exits
while True:
	# store loop start time
	startTime = time.time()

	# capture the next image
	img = input.Capture()

	# detect objects in the image (with overlay)
	detections = net.Detect(img, overlay=opt.overlay)

	# print the detections
	jetson.utils.cudaOverlay(imgBlank, imgOut, 0, 0)
	jetson.utils.cudaOverlay(imgBlank, imgOut, 640, 0)
	jetson.utils.cudaOverlay(img, imgOut, 1280, 0)

	if not movementPaused:
		if len(detections) == 0:
			if not isFrameWithoutDetection:
				isFrameWithoutDetection = True
				withoutStrawStartTime = time.time()
			elif time.time() - withoutStrawStartTime > strawNotDetectedPeriod:
				if not isTuvastajaEmpty:
					print("Tuvastaja is empty!")
					relay_control.line_empty()
				isTuvastajaEmpty = True
		else:
			if isFrameWithoutDetection:
				if isTuvastajaEmpty:
					print("Tuvastaja is not empty!")
					relay_control.line_not_empty()
				isTuvastajaEmpty = False
			isFrameWithoutDetection = False

	for detection in detections:
		#print(detection)
		class_name = net.GetClassDesc(detection.ClassID)
		center = detection.Center
		x = center[0] + 1280
		y = center[1]
		#print(f"Detected '{class_name}' at x={x} y={y}")
		#jetson.utils.cudaOverlay(imgPointer, imgOut, x, y)
		if not movementPaused:
			checkDetectedArea(x, y, class_name)

	updateMovement()

	# render the image
	output.Render(imgOut)

	# update the title bar
	#output.SetStatus("{:s} | Network {:.0f} FPS".format(opt.network, net.GetNetworkFPS()))
	output.SetStatus("xPositions " + str(len(xPositions)))

	# print out performance info
	#net.PrintProfilerTimes()

	loopDuration = time.time() - startTime

	if loopDuration < 0.02:
		time.sleep(0.02 - loopDuration)

	loopDuration = time.time() - startTime
	realFps = round(1.0 / loopDuration, 2)
	#print(f"--- real fps {realFps} ---")

	# exit on input/output EOS
	if not input.IsStreaming() or not output.IsStreaming():
		print("finishing up..")
		relay_control.relay_cleanup()
		break
