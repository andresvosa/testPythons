class J2tk:
	def __init__(self, xPos, cut, cutLength = 200):
		self.xPos = xPos
		self.cut = cut
		self.cutLength = cutLength
