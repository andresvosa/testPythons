#!/usr/bin/env python

# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

import Jetson.GPIO as GPIO
import time

# Pin Definitions
# BCM on siis raspberry pi pinouti järgi
#output_pin  = 17  # BCM pin 17, BOARD pin 11
#output_pin2 = 27  # BCM pin 27, BOARD pin 13
#output_pin3 = 22  # BCM pin 22, BOARD pin 15

movement_pin = 22 # konveier tööle ja kui konveier seisma siis lõige ,Output pin1 kaablil
isEmpty_pin  = 17 # output pin2 kaablil
cut200or150_pin  = 27 # kui bit üleval siis on 200mm lõige, bit=0 siis 150mm , output pin3

def relay_setup():
	# Pin Setup:
	GPIO.setmode(GPIO.BCM)  # BCM pin-numbering scheme from Raspberry Pi
	# saab kasutada ka GPIO.setmode(GPIO.BOARD), siis on numbrid mis plaadil kirjas
	# set pin as an output pin with optional initial state of HIGH
	time.sleep(0.25)
	GPIO.setup(movement_pin, GPIO.OUT, initial=GPIO.LOW)
	GPIO.setup(isEmpty_pin, GPIO.OUT, initial=GPIO.LOW)
	GPIO.setup(cut200or150_pin, GPIO.OUT, initial=GPIO.LOW)
	
	GPIO.output(movement_pin, GPIO.LOW)
	GPIO.output(isEmpty_pin, GPIO.LOW)
	GPIO.output(cut200or150_pin, GPIO.LOW)


def relay_cleanup():
	GPIO.output(movement_pin, GPIO.LOW)
	GPIO.output(isEmpty_pin, GPIO.LOW)
	GPIO.output(cut200or150_pin, GPIO.LOW)
	GPIO.cleanup()

def pause_movement():
	GPIO.output(movement_pin, GPIO.LOW)

def resume_movement():
	GPIO.output(movement_pin, GPIO.HIGH)

def line_empty():
	GPIO.output(isEmpty_pin, GPIO.HIGH)

def line_not_empty():
	GPIO.output(isEmpty_pin, GPIO.LOW)

def cut_length_200():
	GPIO.output(cut200or150_pin, GPIO.HIGH)

def cut_length_150():
	GPIO.output(cut200or150_pin, GPIO.LOW)
